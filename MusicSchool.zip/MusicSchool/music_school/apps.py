from django.apps import AppConfig


class MusicSchoolConfig(AppConfig):
    name = 'music_school'
